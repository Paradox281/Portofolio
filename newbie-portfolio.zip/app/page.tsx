"use client"

import { Canvas } from "@react-three/fiber"
import { OrbitControls, Text3D, Environment } from "@react-three/drei"
import { Suspense, useRef, useState, useEffect } from "react"
import { useFrame } from "@react-three/fiber"
import type { Mesh } from "three"
import * as THREE from "three"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import {
  Github,
  Linkedin,
  Mail,
  ExternalLink,
  Code,
  Database,
  Globe,
  Server,
  ChevronLeft,
  ChevronRight,
  MapPin,
  Calendar,
  Heart,
} from "lucide-react"

function AnimatedCat() {
  const meshRef = useRef<Mesh>(null)
  const [texture, setTexture] = useState<THREE.Texture | null>(null)

  useEffect(() => {
    // Create canvas texture
    const canvas = document.createElement("canvas")
    const ctx = canvas.getContext("2d")
    canvas.width = 512
    canvas.height = 512

    if (ctx) {
      // Create gradient background
      const gradient = ctx.createRadialGradient(256, 256, 0, 256, 256, 256)
      gradient.addColorStop(0, "rgba(59, 130, 246, 0.3)")
      gradient.addColorStop(1, "rgba(147, 51, 234, 0.1)")
      ctx.fillStyle = gradient
      ctx.fillRect(0, 0, 512, 512)

      // Draw cute cat emoji
      ctx.font = "200px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillStyle = "#3b82f6"
      ctx.fillText("🐱", 256, 256)
    }

    const canvasTexture = new THREE.CanvasTexture(canvas)
    canvasTexture.needsUpdate = true
    setTexture(canvasTexture)
  }, [])

  useFrame((state) => {
    if (meshRef.current) {
      // Gentle floating motion
      meshRef.current.position.y = Math.sin(state.clock.elapsedTime * 0.5) * 0.3
      // Slow rotation
      meshRef.current.rotation.y = state.clock.elapsedTime * 0.2
      // Slight tilt animation
      meshRef.current.rotation.z = Math.sin(state.clock.elapsedTime * 0.3) * 0.1
    }
  })

  if (!texture) return null

  return (
    <mesh ref={meshRef} position={[0, 0, 0]} scale={[2, 2, 2]}>
      <planeGeometry args={[2, 2]} />
      <meshStandardMaterial map={texture} transparent opacity={0.9} />
    </mesh>
  )
}

function FloatingCode() {
  const textRef = useRef<any>(null)

  useFrame((state) => {
    if (textRef.current) {
      textRef.current.position.y = Math.sin(state.clock.elapsedTime) * 0.5
      textRef.current.rotation.y = state.clock.elapsedTime * 0.1
    }
  })

  return (
    <Text3D ref={textRef} font="/fonts/Geist_Bold.json" size={0.3} height={0.1} position={[-1, 2, 0]}>
      {"</>"}
      <meshStandardMaterial color="#10b981" />
    </Text3D>
  )
}

function TypedName() {
  const nameRef = useRef<HTMLSpanElement>(null)

  useEffect(() => {
    if (typeof window !== "undefined" && nameRef.current) {
      // Load TypeIt.js dynamically
      const script = document.createElement("script")
      script.src = "https://unpkg.com/typeit@8.7.1/dist/index.umd.js"
      script.onload = () => {
        if (window.TypeIt && nameRef.current) {
          new window.TypeIt(nameRef.current, {
            strings: ["Ahmad Rizki Pratama"],
            speed: 100,
            waitUntilVisible: true,
            cursor: true,
            cursorChar: "|",
            cursorSpeed: 1000,
            deleteSpeed: 50,
            lifeLike: true,
          }).go()
        }
      }
      document.head.appendChild(script)

      return () => {
        if (document.head.contains(script)) {
          document.head.removeChild(script)
        }
      }
    }
  }, [])

  return <span ref={nameRef} className="text-4xl md:text-5xl font-bold text-gray-800"></span>
}

function ProjectSlider({ projects }: { projects: any[] }) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isAnimating, setIsAnimating] = useState(false)

  const nextSlide = () => {
    if (isAnimating) return
    setIsAnimating(true)
    setCurrentIndex((prev) => (prev + 1) % projects.length)
    setTimeout(() => setIsAnimating(false), 500)
  }

  const prevSlide = () => {
    if (isAnimating) return
    setIsAnimating(true)
    setCurrentIndex((prev) => (prev - 1 + projects.length) % projects.length)
    setTimeout(() => setIsAnimating(false), 500)
  }

  useEffect(() => {
    const interval = setInterval(nextSlide, 5000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="relative max-w-4xl mx-auto">
      <div className="overflow-hidden rounded-xl">
        <div
          className="flex transition-transform duration-500 ease-in-out"
          style={{ transform: `translateX(-${currentIndex * 100}%)` }}
        >
          {projects.map((project, index) => (
            <div key={index} className="w-full flex-shrink-0 px-4">
              <Card className="bg-white border-gray-200 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
                <div className="aspect-video bg-gray-100 relative overflow-hidden rounded-t-lg">
                  <img
                    src={project.image || "/placeholder.svg"}
                    alt={project.title}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <CardHeader>
                  <CardTitle className="text-gray-800 text-xl">{project.title}</CardTitle>
                  <CardDescription className="text-gray-600">{project.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="text-gray-800 font-semibold mb-2">Fitur Utama:</h4>
                    <ul className="text-gray-600 text-sm space-y-1">
                      {project.features.map((feature: string, idx: number) => (
                        <li key={idx} className="flex items-center gap-2">
                          <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="text-gray-800 font-semibold mb-2">Teknologi:</h4>
                    <div className="flex flex-wrap gap-2">
                      {project.tech.map((tech: string, idx: number) => (
                        <Badge key={idx} className="bg-blue-100 text-blue-800 hover:bg-blue-200">
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-3 pt-4">
                    <Button size="sm" className="bg-gray-800 hover:bg-gray-700 text-white">
                      <Github className="w-4 h-4 mr-2" />
                      GitHub
                    </Button>
                    {project.demo && (
                      <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Demo
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      </div>

      {/* Navigation Buttons */}
      <Button
        onClick={prevSlide}
        className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 bg-white shadow-lg hover:bg-gray-50 text-gray-800 rounded-full p-2"
        disabled={isAnimating}
      >
        <ChevronLeft className="w-6 h-6" />
      </Button>
      <Button
        onClick={nextSlide}
        className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 bg-white shadow-lg hover:bg-gray-50 text-gray-800 rounded-full p-2"
        disabled={isAnimating}
      >
        <ChevronRight className="w-6 h-6" />
      </Button>

      {/* Dots Indicator */}
      <div className="flex justify-center mt-6 space-x-2">
        {projects.map((_, index) => (
          <button
            key={index}
            onClick={() => !isAnimating && setCurrentIndex(index)}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === currentIndex ? "bg-blue-600 scale-125" : "bg-gray-300 hover:bg-gray-400"
            }`}
          />
        ))}
      </div>
    </div>
  )
}

function SkillCard({ skill, index }: { skill: any; index: number }) {
  return (
    <Card
      className="bg-white border-gray-200 shadow-md hover:shadow-lg transition-all duration-500 transform hover:-translate-y-1"
      data-aos="fade-up"
      data-aos-delay={index * 100}
    >
      <CardHeader className="pb-3">
        <div className="flex items-center gap-3">
          <div className={`p-3 rounded-lg ${skill.color} shadow-sm`}>{skill.icon}</div>
          <div>
            <CardTitle className="text-gray-800 text-lg">{skill.name}</CardTitle>
            <Badge variant="secondary" className="mt-1 bg-gray-100 text-gray-700">
              {skill.level}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div className="flex justify-between text-sm text-gray-600">
            <span>Progress</span>
            <span>{skill.progress}%</span>
          </div>
          <Progress value={skill.progress} className="h-2" />
        </div>
      </CardContent>
    </Card>
  )
}

export default function Portfolio() {
  useEffect(() => {
    // Load AOS library
    const aosScript = document.createElement("script")
    aosScript.src = "https://unpkg.com/aos@2.3.1/dist/aos.js"
    aosScript.onload = () => {
      if (window.AOS) {
        window.AOS.init({
          duration: 800,
          easing: "ease-in-out",
          once: true,
          offset: 100,
        })
      }
    }
    document.head.appendChild(aosScript)

    // Load AOS CSS
    const aosCSS = document.createElement("link")
    aosCSS.rel = "stylesheet"
    aosCSS.href = "https://unpkg.com/aos@2.3.1/dist/aos.css"
    document.head.appendChild(aosCSS)

    return () => {
      if (document.head.contains(aosScript)) {
        document.head.removeChild(aosScript)
      }
      if (document.head.contains(aosCSS)) {
        document.head.removeChild(aosCSS)
      }
    }
  }, [])

  const skills = [
    {
      name: "Java SpringBoot",
      level: "Pemula",
      progress: 30,
      icon: <Server className="w-6 h-6 text-white" />,
      color: "bg-orange-500",
    },
    {
      name: "JavaScript",
      level: "Pemula",
      progress: 40,
      icon: <Code className="w-6 h-6 text-white" />,
      color: "bg-yellow-500",
    },
    {
      name: "HTML",
      level: "Pemula",
      progress: 50,
      icon: <Globe className="w-6 h-6 text-white" />,
      color: "bg-red-500",
    },
    {
      name: "CSS",
      level: "Pemula",
      progress: 45,
      icon: <Globe className="w-6 h-6 text-white" />,
      color: "bg-blue-500",
    },
    {
      name: "Tailwind CSS",
      level: "Pemula",
      progress: 35,
      icon: <Globe className="w-6 h-6 text-white" />,
      color: "bg-cyan-500",
    },
    {
      name: "Python",
      level: "Pemula",
      progress: 25,
      icon: <Code className="w-6 h-6 text-white" />,
      color: "bg-green-500",
    },
    { name: "C", level: "Pemula", progress: 20, icon: <Code className="w-6 h-6 text-white" />, color: "bg-gray-600" },
    {
      name: "Laravel",
      level: "Pemula",
      progress: 30,
      icon: <Server className="w-6 h-6 text-white" />,
      color: "bg-red-600",
    },
    {
      name: "PHP",
      level: "Pemula",
      progress: 35,
      icon: <Code className="w-6 h-6 text-white" />,
      color: "bg-purple-600",
    },
    {
      name: "MySQL",
      level: "Pemula",
      progress: 40,
      icon: <Database className="w-6 h-6 text-white" />,
      color: "bg-blue-600",
    },
    {
      name: "PostgreSQL",
      level: "Pemula",
      progress: 25,
      icon: <Database className="w-6 h-6 text-white" />,
      color: "bg-blue-700",
    },
  ]

  const projects = [
    {
      title: "Sistem Manajemen Perpustakaan",
      description: "Aplikasi web sederhana untuk mengelola buku dan peminjaman di perpustakaan",
      features: ["CRUD Buku", "Sistem Peminjaman", "Dashboard Admin", "Laporan Sederhana"],
      tech: ["PHP", "MySQL", "HTML", "CSS", "JavaScript"],
      image: "/placeholder.svg?height=200&width=300",
      github: "https://github.com/username/library-system",
      demo: "https://library-demo.vercel.app",
    },
    {
      title: "Todo List App",
      description: "Aplikasi todo list dengan fitur dasar untuk mengelola tugas harian",
      features: ["Tambah/Hapus Task", "Mark Complete", "Filter Status", "Local Storage"],
      tech: ["JavaScript", "HTML", "CSS", "Tailwind"],
      image: "/placeholder.svg?height=200&width=300",
      github: "https://github.com/username/todo-app",
      demo: "https://todo-demo.vercel.app",
    },
    {
      title: "Kalkulator Sederhana",
      description: "Kalkulator web dengan operasi matematika dasar menggunakan JavaScript",
      features: ["Operasi Dasar", "History", "Responsive Design", "Keyboard Support"],
      tech: ["JavaScript", "HTML", "CSS"],
      image: "/placeholder.svg?height=200&width=300",
      github: "https://github.com/username/calculator",
      demo: "https://calc-demo.vercel.app",
    },
    {
      title: "API Sederhana dengan SpringBoot",
      description: "REST API sederhana untuk manajemen data mahasiswa",
      features: ["CRUD Operations", "Validation", "Error Handling", "Documentation"],
      tech: ["Java", "SpringBoot", "MySQL"],
      image: "/placeholder.svg?height=200&width=300",
      github: "https://github.com/username/student-api",
      demo: null,
    },
  ]

  const experiences = [
    {
      type: "Belajar",
      title: "Sedang Belajar ReactJS",
      description: "Mempelajari library React untuk pengembangan frontend modern",
      period: "Saat ini",
      status: "ongoing",
    },
    {
      type: "Kursus",
      title: "Bootcamp Web Development",
      description: "Mengikuti bootcamp intensif untuk mempelajari full-stack development",
      period: "2024",
      status: "completed",
    },
    {
      type: "Proyek",
      title: "Freelance Project",
      description: "Membuat website sederhana untuk UMKM lokal",
      period: "2024",
      status: "completed",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100">
      {/* Hero Section with 3D Cat Animation */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="absolute inset-0 w-full h-full opacity-80">
          <Canvas camera={{ position: [0, 0, 5] }}>
            <Suspense fallback={null}>
              <Environment preset="city" />
              <ambientLight intensity={0.6} />
              <pointLight position={[10, 10, 10]} />
              <AnimatedCat />
              <FloatingCode />
              <OrbitControls enableZoom={false} enablePan={false} />
            </Suspense>
          </Canvas>
        </div>

        <div className="relative z-10 text-center px-4">
          <h1 className="text-5xl md:text-7xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Halo, Saya Developer 🐱
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-700">
            Newbie Programmer yang Passionate dalam Web Development
          </p>
          <div className="flex gap-4 justify-center">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white shadow-lg">
              Lihat Portfolio
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-white border-gray-300 text-gray-700 hover:bg-gray-50 shadow-lg"
            >
              Hubungi Saya
            </Button>
          </div>
        </div>
      </section>

      {/* About Me Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Photo Section */}
            <div className="flex justify-center lg:justify-start" data-aos="fade-right">
              <div className="relative">
                <div className="w-80 h-80 rounded-full overflow-hidden shadow-2xl bg-gradient-to-br from-blue-100 to-purple-100 flex items-center justify-center">
                  <img
                    src="/placeholder.svg?height=320&width=320"
                    alt="Profile Photo"
                    className="w-full h-full object-cover"
                  />
                </div>
                {/* Decorative elements with cat theme */}
                <div className="absolute -top-4 -right-4 w-20 h-20 bg-blue-500 rounded-full opacity-20 animate-pulse flex items-center justify-center text-2xl">
                  🐾
                </div>
                <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-purple-500 rounded-full opacity-20 animate-pulse delay-1000 flex items-center justify-center text-xl">
                  🐱
                </div>
              </div>
            </div>

            {/* Content Section */}
            <div className="space-y-6" data-aos="fade-left">
              <div>
                <h2 className="text-3xl font-bold text-gray-800 mb-4">Tentang Saya</h2>
                <TypedName />
              </div>

              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p className="text-lg">
                  Halo! Saya seorang <span className="font-semibold text-blue-600">newbie programmer</span> yang
                  passionate dalam dunia web development. Meskipun masih dalam tahap pembelajaran, saya memiliki
                  semangat tinggi untuk terus berkembang dan menciptakan solusi digital yang bermanfaat.
                </p>

                <p>
                  Saat ini saya fokus mempelajari teknologi{" "}
                  <span className="font-semibold text-purple-600">full-stack development</span> dengan berbagai bahasa
                  pemrograman seperti Java, JavaScript, PHP, dan Python. Setiap hari adalah kesempatan baru untuk
                  belajar dan mengasah kemampuan coding saya.
                </p>

                <p>
                  <span className="font-semibold text-green-600">Tujuan saya</span> adalah menjadi seorang developer
                  yang dapat berkontribusi dalam menciptakan aplikasi web yang user-friendly dan memberikan dampak
                  positif bagi pengguna. Saya percaya bahwa dengan konsistensi dan dedikasi, impian untuk menjadi
                  programmer profesional akan tercapai.
                </p>
              </div>

              {/* Quick Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-6">
                <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                  <MapPin className="w-5 h-5 text-blue-500" />
                  <div>
                    <p className="text-sm text-gray-500">Lokasi</p>
                    <p className="font-semibold text-gray-800">Jakarta, Indonesia</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                  <Calendar className="w-5 h-5 text-green-500" />
                  <div>
                    <p className="text-sm text-gray-500">Mulai Coding</p>
                    <p className="font-semibold text-gray-800">2024</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                  <Code className="w-5 h-5 text-purple-500" />
                  <div>
                    <p className="text-sm text-gray-500">Fokus</p>
                    <p className="font-semibold text-gray-800">Web Development</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                  <Heart className="w-5 h-5 text-red-500" />
                  <div>
                    <p className="text-sm text-gray-500">Passion</p>
                    <p className="font-semibold text-gray-800">Problem Solving</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div data-aos="fade-up" className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Teknologi yang Dikuasai</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Berikut adalah teknologi yang sedang saya pelajari dan kembangkan sebagai seorang programmer pemula
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {skills.map((skill, index) => (
              <SkillCard key={index} skill={skill} index={index} />
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div data-aos="fade-up" className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Proyek Terbaik Saya</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Koleksi proyek sederhana yang telah saya buat selama perjalanan belajar programming
            </p>
          </div>
          <div data-aos="fade-up" data-aos-delay="200">
            <ProjectSlider projects={projects} />
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="max-w-4xl mx-auto">
          <div data-aos="fade-up" className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Pengalaman & Progress</h2>
            <p className="text-gray-600">Perjalanan belajar dan pengalaman yang telah saya lalui</p>
          </div>
          <div className="space-y-6">
            {experiences.map((exp, index) => (
              <Card
                key={index}
                className="bg-white border-gray-200 shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1"
                data-aos="fade-up"
                data-aos-delay={index * 100}
              >
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <Badge className="mb-2 bg-purple-100 text-purple-800">{exp.type}</Badge>
                      <CardTitle className="text-gray-800 text-xl">{exp.title}</CardTitle>
                      <CardDescription className="text-gray-600 mt-2">{exp.description}</CardDescription>
                    </div>
                    <div className="text-right">
                      <p className="text-gray-500 text-sm">{exp.period}</p>
                      <Badge
                        variant={exp.status === "ongoing" ? "default" : "secondary"}
                        className={
                          exp.status === "ongoing" ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-700"
                        }
                      >
                        {exp.status === "ongoing" ? "Sedang Berlangsung" : "Selesai"}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 px-4 bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="max-w-4xl mx-auto text-center">
          <div data-aos="fade-up">
            <h2 className="text-4xl font-bold mb-4 text-gray-800">Mari Berkolaborasi!</h2>
            <p className="text-xl text-gray-600 mb-12">
              Saya terbuka untuk peluang belajar, magang, atau proyek kolaborasi
            </p>

            <div className="flex justify-center gap-6 mb-12">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white shadow-lg">
                <Mail className="w-5 h-5 mr-2" />
                Email
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="bg-white border-gray-300 text-gray-700 hover:bg-gray-50 shadow-lg"
              >
                <Github className="w-5 h-5 mr-2" />
                GitHub
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="bg-white border-gray-300 text-gray-700 hover:bg-gray-50 shadow-lg"
              >
                <Linkedin className="w-5 h-5 mr-2" />
                LinkedIn
              </Button>
            </div>

            <div className="text-gray-500">
              <p>© 2024 Portfolio Newbie Developer. Dibuat dengan ❤️ menggunakan Next.js & Three.js</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
