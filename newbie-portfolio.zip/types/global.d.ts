declare global {
  interface Window {
    TypeIt: any
    AOS: any
  }
}

export {}
